sources used
    https://www.youtube.com/watch?v=bEmBh1HtYrw - Bloom Filters
    https://en.wikipedia.org/wiki/Bloom_filter
    https://en.wikipedia.org/wiki/Fowler%E2%80%93Noll%E2%80%93Vo_hash_function
    https://softwareengineering.stackexchange.com/questions/197374/what-is-the-time-complexity-of-the-algorithm-to-check-if-a-number-is-prime - how to find next biggest prime
    https://stackoverflow.com/questions/52353/in-java-what-is-the-best-way-to-determine-the-size-of-an-object for size determination.

to compile main code run "make"
to compile test run "make test"