package arithlang;
import static arithlang.AST.*;
import static arithlang.Value.*;

import java.util.List;

public class Evaluator implements Visitor<Value> {

    Printer.Formatter ts = new Printer.Formatter();
    private NumVal memory = new NumVal(0d);

    Value valueOf(Program p) {
    // Value of a program in this language is the value of the expression
        return (Value) p.accept(this);
    }

    @Override
    public Value visit(AddExp e) {
        List<Exp> operands = e.all();
        double result = 0;
        for(Exp exp: operands) {
            Value val = (Value) exp.accept(this);
            if( val instanceof NumVal){
                result += ((NumVal) val).v(); //Semantics of AddExp in terms of the target language.
            } else{
                return val;
            }
        }
        return new NumVal(result);
    }

    @Override
    public Value visit(NumExp e) {
        return new NumVal(e.v());
    }

    @Override
    public Value visit(DivExp e) {
        List<Exp> operands = e.all();
        int i = 0;
        Boolean dbz = false;
        Value val = (Value) operands.get(i).accept(this);
        try{
            double result = ((NumVal) val).v();
            for(i = 1; i<operands.size() && !dbz; i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                if (rVal.v() == 0){
                    dbz = true;
                } else{
                    result = result / rVal.v();
                }
            }
            if(dbz){
                return new DynamicError("divide by zero occured here: " + e.accept(ts));
            } else{
                return new NumVal(result);
            }
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(MultExp e) {
        List<Exp> operands = e.all();
        double result = 1;
        for(Exp exp: operands) {
            Value intermediate = (Value) exp.accept(this); // Dynamic type-checking
            if(intermediate instanceof NumVal){
                result *= ((NumVal)intermediate).v(); //Semantics of MultExp.
            } else{
                return intermediate;
            }
        }
        return new NumVal(result);
    }

    @Override
    public Value visit(Program p) {
        return (Value) p.e().accept(this);
    }

    @Override
    public Value visit(SubExp e) {
        List<Exp> operands = e.all();
        Value val = (Value) operands.get(0).accept(this);
        try{
            double result = ((NumVal)val).v();
            for(int i=1; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                result = result - rVal.v();
            }
            return new NumVal(result);
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(ModExp e) {
        List<Exp> operands = e.all();
        Value val = (Value) operands.get(0).accept(this);
        try{
            double result = ((NumVal)val).v();
            for(int i=1; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                if( rVal.v() == 0 ){
                    return new DynamicError("divide by zero occured here: " + e.accept(ts));
                } else{
                    result = result % rVal.v();
                }
            }
            return new NumVal(result);
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(PowExp e) {
        List<Exp> operands = e.all();
        Value val = (Value) operands.get(0).accept(this);
        try{
            double result = ((NumVal)val).v();
            for(int i=1; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                result = Math.pow( result, rVal.v());
            }
            return new NumVal(result);
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(GrtExp e) {
        List<Exp> operands = e.all();
        Value val = (Value) operands.get(0).accept(this);
        try{
            double result = ((NumVal)val).v();
            for(int i=1; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                result = result < rVal.v() ? rVal.v() : result;
            }
            return new NumVal(result);
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(LstExp e) {
        List<Exp> operands = e.all();
        Value val = (Value) operands.get(0).accept(this);
        try{
            double result = ((NumVal)val).v();
            for(int i=1; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                result = result > rVal.v() ? rVal.v() : result;
            }
            return new NumVal(result);
        } catch(ClassCastException c){
            return val;
        }
    }

    @Override
    public Value visit(MrecExp e){
        if(e.isClear()){
            this.memory = new NumVal(0d);
        }
        return this.memory;
    }

    @Override
    public Value visit(MaddExp e){
       List<Exp> operands = e.all();
        double result = this.memory.v();
        for(Exp exp: operands) {
            Value val = (Value) exp.accept(this);
            if( val instanceof NumVal){
                result += ((NumVal) val).v(); //Semantics of AddExp in terms of the target language.
            } else{
                return val;
            }
        }
        this.memory = new NumVal(result);
        return this.memory;
    }

    @Override
    public Value visit(MsubExp e) {
        List<Exp> operands = e.all();
        Value val = this.memory;
        try{
            double result = ((NumVal)val).v();
            for(int i=0; i<operands.size(); i++) {
                val = (Value) operands.get(i).accept(this);
                NumVal rVal = (NumVal) val;
                result = result - rVal.v();
            }
            this.memory = new NumVal(result);
            return this.memory;
        } catch(ClassCastException c){
            return val;
        }
    }
}
