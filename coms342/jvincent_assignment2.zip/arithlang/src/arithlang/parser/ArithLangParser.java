// Generated from ArithLang.g by ANTLR 4.5
package arithlang.parser; import static arithlang.AST.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class ArithLangParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, Dot=15, Number=16, Identifier=17, 
		Letter=18, LetterOrDigit=19, AT=20, ELLIPSIS=21, WS=22, Comment=23, Line_Comment=24;
	public static final int
		RULE_program = 0, RULE_exp = 1, RULE_numexp = 2, RULE_addexp = 3, RULE_subexp = 4, 
		RULE_multexp = 5, RULE_divexp = 6, RULE_modexp = 7, RULE_powexp = 8, RULE_grtexp = 9, 
		RULE_lstexp = 10, RULE_maddexp = 11, RULE_msubexp = 12, RULE_mrecexp = 13;
	public static final String[] ruleNames = {
		"program", "exp", "numexp", "addexp", "subexp", "multexp", "divexp", "modexp", 
		"powexp", "grtexp", "lstexp", "maddexp", "msubexp", "mrecexp"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'-'", "'('", "'+'", "')'", "'*'", "'/'", "'%'", "'**'", "'>?'", 
		"'<?'", "'M+'", "'M-'", "'Mrec'", "'Mclr'", "'.'", null, null, null, null, 
		"'@'", "'...'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, null, null, null, null, 
		null, null, null, "Dot", "Number", "Identifier", "Letter", "LetterOrDigit", 
		"AT", "ELLIPSIS", "WS", "Comment", "Line_Comment"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "ArithLang.g"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public ArithLangParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public Program ast;
		public ExpContext e;
		public ExpContext exp() {
			return getRuleContext(ExpContext.class,0);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(28);
			((ProgramContext)_localctx).e = exp();
			 ((ProgramContext)_localctx).ast =  new Program(((ProgramContext)_localctx).e.ast); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpContext extends ParserRuleContext {
		public Exp ast;
		public NumexpContext n;
		public AddexpContext a;
		public SubexpContext s;
		public MultexpContext m;
		public DivexpContext d;
		public ModexpContext o;
		public PowexpContext p;
		public GrtexpContext g;
		public LstexpContext l;
		public MrecexpContext mr;
		public MaddexpContext ma;
		public MsubexpContext ms;
		public NumexpContext numexp() {
			return getRuleContext(NumexpContext.class,0);
		}
		public AddexpContext addexp() {
			return getRuleContext(AddexpContext.class,0);
		}
		public SubexpContext subexp() {
			return getRuleContext(SubexpContext.class,0);
		}
		public MultexpContext multexp() {
			return getRuleContext(MultexpContext.class,0);
		}
		public DivexpContext divexp() {
			return getRuleContext(DivexpContext.class,0);
		}
		public ModexpContext modexp() {
			return getRuleContext(ModexpContext.class,0);
		}
		public PowexpContext powexp() {
			return getRuleContext(PowexpContext.class,0);
		}
		public GrtexpContext grtexp() {
			return getRuleContext(GrtexpContext.class,0);
		}
		public LstexpContext lstexp() {
			return getRuleContext(LstexpContext.class,0);
		}
		public MrecexpContext mrecexp() {
			return getRuleContext(MrecexpContext.class,0);
		}
		public MaddexpContext maddexp() {
			return getRuleContext(MaddexpContext.class,0);
		}
		public MsubexpContext msubexp() {
			return getRuleContext(MsubexpContext.class,0);
		}
		public ExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exp; }
	}

	public final ExpContext exp() throws RecognitionException {
		ExpContext _localctx = new ExpContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_exp);
		try {
			setState(67);
			switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(31);
				((ExpContext)_localctx).n = numexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).n.ast; 
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(34);
				((ExpContext)_localctx).a = addexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).a.ast; 
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(37);
				((ExpContext)_localctx).s = subexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).s.ast; 
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(40);
				((ExpContext)_localctx).m = multexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).m.ast; 
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(43);
				((ExpContext)_localctx).d = divexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).d.ast; 
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(46);
				((ExpContext)_localctx).o = modexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).o.ast; 
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(49);
				((ExpContext)_localctx).p = powexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).p.ast; 
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(52);
				((ExpContext)_localctx).g = grtexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).g.ast; 
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(55);
				((ExpContext)_localctx).l = lstexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).l.ast; 
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(58);
				((ExpContext)_localctx).mr = mrecexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).mr.ast; 
				}
				break;
			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(61);
				((ExpContext)_localctx).ma = maddexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).ma.ast; 
				}
				break;
			case 12:
				enterOuterAlt(_localctx, 12);
				{
				setState(64);
				((ExpContext)_localctx).ms = msubexp();
				 ((ExpContext)_localctx).ast =  ((ExpContext)_localctx).ms.ast; 
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumexpContext extends ParserRuleContext {
		public NumExp ast;
		public Token n0;
		public Token n1;
		public List<TerminalNode> Number() { return getTokens(ArithLangParser.Number); }
		public TerminalNode Number(int i) {
			return getToken(ArithLangParser.Number, i);
		}
		public TerminalNode Dot() { return getToken(ArithLangParser.Dot, 0); }
		public NumexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numexp; }
	}

	public final NumexpContext numexp() throws RecognitionException {
		NumexpContext _localctx = new NumexpContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_numexp);
		try {
			setState(83);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(69);
				((NumexpContext)_localctx).n0 = match(Number);
				 ((NumexpContext)_localctx).ast =  new NumExp(Integer.parseInt((((NumexpContext)_localctx).n0!=null?((NumexpContext)_localctx).n0.getText():null))); 
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(71);
				match(T__0);
				setState(72);
				((NumexpContext)_localctx).n0 = match(Number);
				 ((NumexpContext)_localctx).ast =  new NumExp(-Integer.parseInt((((NumexpContext)_localctx).n0!=null?((NumexpContext)_localctx).n0.getText():null))); 
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(74);
				((NumexpContext)_localctx).n0 = match(Number);
				setState(75);
				match(Dot);
				setState(76);
				((NumexpContext)_localctx).n1 = match(Number);
				 ((NumexpContext)_localctx).ast =  new NumExp(Double.parseDouble((((NumexpContext)_localctx).n0!=null?((NumexpContext)_localctx).n0.getText():null)+"."+(((NumexpContext)_localctx).n1!=null?((NumexpContext)_localctx).n1.getText():null))); 
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(78);
				match(T__0);
				setState(79);
				((NumexpContext)_localctx).n0 = match(Number);
				setState(80);
				match(Dot);
				setState(81);
				((NumexpContext)_localctx).n1 = match(Number);
				 ((NumexpContext)_localctx).ast =  new NumExp(Double.parseDouble("-" + (((NumexpContext)_localctx).n0!=null?((NumexpContext)_localctx).n0.getText():null)+"."+(((NumexpContext)_localctx).n1!=null?((NumexpContext)_localctx).n1.getText():null))); 
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AddexpContext extends ParserRuleContext {
		public AddExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public AddexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_addexp; }
	}

	public final AddexpContext addexp() throws RecognitionException {
		AddexpContext _localctx = new AddexpContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_addexp);
		 ((AddexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(85);
			match(T__1);
			setState(86);
			match(T__2);
			setState(87);
			((AddexpContext)_localctx).e = exp();
			 _localctx.list.add(((AddexpContext)_localctx).e.ast); 
			setState(92); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(89);
				((AddexpContext)_localctx).e = exp();
				 _localctx.list.add(((AddexpContext)_localctx).e.ast); 
				}
				}
				setState(94); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(96);
			match(T__3);
			 ((AddexpContext)_localctx).ast =  new AddExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SubexpContext extends ParserRuleContext {
		public SubExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public SubexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subexp; }
	}

	public final SubexpContext subexp() throws RecognitionException {
		SubexpContext _localctx = new SubexpContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_subexp);
		 ((SubexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(99);
			match(T__1);
			setState(100);
			match(T__0);
			setState(101);
			((SubexpContext)_localctx).e = exp();
			 _localctx.list.add(((SubexpContext)_localctx).e.ast); 
			setState(106); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(103);
				((SubexpContext)_localctx).e = exp();
				 _localctx.list.add(((SubexpContext)_localctx).e.ast); 
				}
				}
				setState(108); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(110);
			match(T__3);
			 ((SubexpContext)_localctx).ast =  new SubExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MultexpContext extends ParserRuleContext {
		public MultExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public MultexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multexp; }
	}

	public final MultexpContext multexp() throws RecognitionException {
		MultexpContext _localctx = new MultexpContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_multexp);
		 ((MultexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			match(T__1);
			setState(114);
			match(T__4);
			setState(115);
			((MultexpContext)_localctx).e = exp();
			 _localctx.list.add(((MultexpContext)_localctx).e.ast); 
			setState(120); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(117);
				((MultexpContext)_localctx).e = exp();
				 _localctx.list.add(((MultexpContext)_localctx).e.ast); 
				}
				}
				setState(122); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(124);
			match(T__3);
			 ((MultexpContext)_localctx).ast =  new MultExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DivexpContext extends ParserRuleContext {
		public DivExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public DivexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_divexp; }
	}

	public final DivexpContext divexp() throws RecognitionException {
		DivexpContext _localctx = new DivexpContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_divexp);
		 ((DivexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(127);
			match(T__1);
			setState(128);
			match(T__5);
			setState(129);
			((DivexpContext)_localctx).e = exp();
			 _localctx.list.add(((DivexpContext)_localctx).e.ast); 
			setState(134); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(131);
				((DivexpContext)_localctx).e = exp();
				 _localctx.list.add(((DivexpContext)_localctx).e.ast); 
				}
				}
				setState(136); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(138);
			match(T__3);
			 ((DivexpContext)_localctx).ast =  new DivExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ModexpContext extends ParserRuleContext {
		public ModExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public ModexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_modexp; }
	}

	public final ModexpContext modexp() throws RecognitionException {
		ModexpContext _localctx = new ModexpContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_modexp);
		 ((ModexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(141);
			match(T__1);
			setState(142);
			match(T__6);
			setState(143);
			((ModexpContext)_localctx).e = exp();
			 _localctx.list.add(((ModexpContext)_localctx).e.ast); 
			setState(148); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(145);
				((ModexpContext)_localctx).e = exp();
				 _localctx.list.add(((ModexpContext)_localctx).e.ast); 
				}
				}
				setState(150); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(152);
			match(T__3);
			 ((ModexpContext)_localctx).ast =  new ModExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PowexpContext extends ParserRuleContext {
		public PowExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public PowexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_powexp; }
	}

	public final PowexpContext powexp() throws RecognitionException {
		PowexpContext _localctx = new PowexpContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_powexp);
		 ((PowexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			match(T__1);
			setState(156);
			match(T__7);
			setState(157);
			((PowexpContext)_localctx).e = exp();
			 _localctx.list.add(((PowexpContext)_localctx).e.ast); 
			setState(162); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(159);
				((PowexpContext)_localctx).e = exp();
				 _localctx.list.add(((PowexpContext)_localctx).e.ast); 
				}
				}
				setState(164); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(166);
			match(T__3);
			 ((PowexpContext)_localctx).ast =  new PowExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GrtexpContext extends ParserRuleContext {
		public GrtExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public GrtexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_grtexp; }
	}

	public final GrtexpContext grtexp() throws RecognitionException {
		GrtexpContext _localctx = new GrtexpContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_grtexp);
		 ((GrtexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			match(T__1);
			setState(170);
			match(T__8);
			setState(171);
			((GrtexpContext)_localctx).e = exp();
			 _localctx.list.add(((GrtexpContext)_localctx).e.ast); 
			setState(176); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(173);
				((GrtexpContext)_localctx).e = exp();
				 _localctx.list.add(((GrtexpContext)_localctx).e.ast); 
				}
				}
				setState(178); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(180);
			match(T__3);
			 ((GrtexpContext)_localctx).ast =  new GrtExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LstexpContext extends ParserRuleContext {
		public LstExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public LstexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lstexp; }
	}

	public final LstexpContext lstexp() throws RecognitionException {
		LstexpContext _localctx = new LstexpContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_lstexp);
		 ((LstexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(183);
			match(T__1);
			setState(184);
			match(T__9);
			setState(185);
			((LstexpContext)_localctx).e = exp();
			 _localctx.list.add(((LstexpContext)_localctx).e.ast); 
			setState(190); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(187);
				((LstexpContext)_localctx).e = exp();
				 _localctx.list.add(((LstexpContext)_localctx).e.ast); 
				}
				}
				setState(192); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(194);
			match(T__3);
			 ((LstexpContext)_localctx).ast =  new LstExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MaddexpContext extends ParserRuleContext {
		public MaddExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public MaddexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_maddexp; }
	}

	public final MaddexpContext maddexp() throws RecognitionException {
		MaddexpContext _localctx = new MaddexpContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_maddexp);
		 ((MaddexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(197);
			match(T__1);
			setState(198);
			match(T__10);
			setState(202); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(199);
				((MaddexpContext)_localctx).e = exp();
				 _localctx.list.add(((MaddexpContext)_localctx).e.ast); 
				}
				}
				setState(204); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(206);
			match(T__3);
			 ((MaddexpContext)_localctx).ast =  new MaddExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MsubexpContext extends ParserRuleContext {
		public MsubExp ast;
		public ArrayList<Exp> list;
		public ExpContext e;
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public MsubexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_msubexp; }
	}

	public final MsubexpContext msubexp() throws RecognitionException {
		MsubexpContext _localctx = new MsubexpContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_msubexp);
		 ((MsubexpContext)_localctx).list =  new ArrayList<Exp>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(209);
			match(T__1);
			setState(210);
			match(T__11);
			setState(214); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(211);
				((MsubexpContext)_localctx).e = exp();
				 _localctx.list.add(((MsubexpContext)_localctx).e.ast); 
				}
				}
				setState(216); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << Number))) != 0) );
			setState(218);
			match(T__3);
			 ((MsubexpContext)_localctx).ast =  new MsubExp(_localctx.list); 
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MrecexpContext extends ParserRuleContext {
		public MrecExp ast;
		public Boolean clear;
		public MrecexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mrecexp; }
	}

	public final MrecexpContext mrecexp() throws RecognitionException {
		MrecexpContext _localctx = new MrecexpContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_mrecexp);
		((MrecexpContext)_localctx).clear =  false;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(221);
			match(T__1);
			setState(225);
			switch (_input.LA(1)) {
			case T__12:
				{
				setState(222);
				match(T__12);
				}
				break;
			case T__13:
				{
				setState(223);
				match(T__13);
				((MrecexpContext)_localctx).clear =  true;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(227);
			match(T__3);
			((MrecexpContext)_localctx).ast =  new MrecExp(_localctx.clear);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\32\u00e9\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\3\2\3\2\3\2\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3F\n\3\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4V\n\4\3\5\3"+
		"\5\3\5\3\5\3\5\3\5\3\5\6\5_\n\5\r\5\16\5`\3\5\3\5\3\5\3\6\3\6\3\6\3\6"+
		"\3\6\3\6\3\6\6\6m\n\6\r\6\16\6n\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\7\3"+
		"\7\6\7{\n\7\r\7\16\7|\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\6\b\u0089"+
		"\n\b\r\b\16\b\u008a\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\6\t\u0097"+
		"\n\t\r\t\16\t\u0098\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\6\n\u00a5"+
		"\n\n\r\n\16\n\u00a6\3\n\3\n\3\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\6\13"+
		"\u00b3\n\13\r\13\16\13\u00b4\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3\f\3"+
		"\f\6\f\u00c1\n\f\r\f\16\f\u00c2\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\6\r\u00cd"+
		"\n\r\r\r\16\r\u00ce\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\6\16\u00d9\n"+
		"\16\r\16\16\16\u00da\3\16\3\16\3\16\3\17\3\17\3\17\3\17\5\17\u00e4\n\17"+
		"\3\17\3\17\3\17\3\17\2\2\20\2\4\6\b\n\f\16\20\22\24\26\30\32\34\2\2\u00f3"+
		"\2\36\3\2\2\2\4E\3\2\2\2\6U\3\2\2\2\bW\3\2\2\2\ne\3\2\2\2\fs\3\2\2\2\16"+
		"\u0081\3\2\2\2\20\u008f\3\2\2\2\22\u009d\3\2\2\2\24\u00ab\3\2\2\2\26\u00b9"+
		"\3\2\2\2\30\u00c7\3\2\2\2\32\u00d3\3\2\2\2\34\u00df\3\2\2\2\36\37\5\4"+
		"\3\2\37 \b\2\1\2 \3\3\2\2\2!\"\5\6\4\2\"#\b\3\1\2#F\3\2\2\2$%\5\b\5\2"+
		"%&\b\3\1\2&F\3\2\2\2\'(\5\n\6\2()\b\3\1\2)F\3\2\2\2*+\5\f\7\2+,\b\3\1"+
		"\2,F\3\2\2\2-.\5\16\b\2./\b\3\1\2/F\3\2\2\2\60\61\5\20\t\2\61\62\b\3\1"+
		"\2\62F\3\2\2\2\63\64\5\22\n\2\64\65\b\3\1\2\65F\3\2\2\2\66\67\5\24\13"+
		"\2\678\b\3\1\28F\3\2\2\29:\5\26\f\2:;\b\3\1\2;F\3\2\2\2<=\5\34\17\2=>"+
		"\b\3\1\2>F\3\2\2\2?@\5\30\r\2@A\b\3\1\2AF\3\2\2\2BC\5\32\16\2CD\b\3\1"+
		"\2DF\3\2\2\2E!\3\2\2\2E$\3\2\2\2E\'\3\2\2\2E*\3\2\2\2E-\3\2\2\2E\60\3"+
		"\2\2\2E\63\3\2\2\2E\66\3\2\2\2E9\3\2\2\2E<\3\2\2\2E?\3\2\2\2EB\3\2\2\2"+
		"F\5\3\2\2\2GH\7\22\2\2HV\b\4\1\2IJ\7\3\2\2JK\7\22\2\2KV\b\4\1\2LM\7\22"+
		"\2\2MN\7\21\2\2NO\7\22\2\2OV\b\4\1\2PQ\7\3\2\2QR\7\22\2\2RS\7\21\2\2S"+
		"T\7\22\2\2TV\b\4\1\2UG\3\2\2\2UI\3\2\2\2UL\3\2\2\2UP\3\2\2\2V\7\3\2\2"+
		"\2WX\7\4\2\2XY\7\5\2\2YZ\5\4\3\2Z^\b\5\1\2[\\\5\4\3\2\\]\b\5\1\2]_\3\2"+
		"\2\2^[\3\2\2\2_`\3\2\2\2`^\3\2\2\2`a\3\2\2\2ab\3\2\2\2bc\7\6\2\2cd\b\5"+
		"\1\2d\t\3\2\2\2ef\7\4\2\2fg\7\3\2\2gh\5\4\3\2hl\b\6\1\2ij\5\4\3\2jk\b"+
		"\6\1\2km\3\2\2\2li\3\2\2\2mn\3\2\2\2nl\3\2\2\2no\3\2\2\2op\3\2\2\2pq\7"+
		"\6\2\2qr\b\6\1\2r\13\3\2\2\2st\7\4\2\2tu\7\7\2\2uv\5\4\3\2vz\b\7\1\2w"+
		"x\5\4\3\2xy\b\7\1\2y{\3\2\2\2zw\3\2\2\2{|\3\2\2\2|z\3\2\2\2|}\3\2\2\2"+
		"}~\3\2\2\2~\177\7\6\2\2\177\u0080\b\7\1\2\u0080\r\3\2\2\2\u0081\u0082"+
		"\7\4\2\2\u0082\u0083\7\b\2\2\u0083\u0084\5\4\3\2\u0084\u0088\b\b\1\2\u0085"+
		"\u0086\5\4\3\2\u0086\u0087\b\b\1\2\u0087\u0089\3\2\2\2\u0088\u0085\3\2"+
		"\2\2\u0089\u008a\3\2\2\2\u008a\u0088\3\2\2\2\u008a\u008b\3\2\2\2\u008b"+
		"\u008c\3\2\2\2\u008c\u008d\7\6\2\2\u008d\u008e\b\b\1\2\u008e\17\3\2\2"+
		"\2\u008f\u0090\7\4\2\2\u0090\u0091\7\t\2\2\u0091\u0092\5\4\3\2\u0092\u0096"+
		"\b\t\1\2\u0093\u0094\5\4\3\2\u0094\u0095\b\t\1\2\u0095\u0097\3\2\2\2\u0096"+
		"\u0093\3\2\2\2\u0097\u0098\3\2\2\2\u0098\u0096\3\2\2\2\u0098\u0099\3\2"+
		"\2\2\u0099\u009a\3\2\2\2\u009a\u009b\7\6\2\2\u009b\u009c\b\t\1\2\u009c"+
		"\21\3\2\2\2\u009d\u009e\7\4\2\2\u009e\u009f\7\n\2\2\u009f\u00a0\5\4\3"+
		"\2\u00a0\u00a4\b\n\1\2\u00a1\u00a2\5\4\3\2\u00a2\u00a3\b\n\1\2\u00a3\u00a5"+
		"\3\2\2\2\u00a4\u00a1\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\u00a4\3\2\2\2\u00a6"+
		"\u00a7\3\2\2\2\u00a7\u00a8\3\2\2\2\u00a8\u00a9\7\6\2\2\u00a9\u00aa\b\n"+
		"\1\2\u00aa\23\3\2\2\2\u00ab\u00ac\7\4\2\2\u00ac\u00ad\7\13\2\2\u00ad\u00ae"+
		"\5\4\3\2\u00ae\u00b2\b\13\1\2\u00af\u00b0\5\4\3\2\u00b0\u00b1\b\13\1\2"+
		"\u00b1\u00b3\3\2\2\2\u00b2\u00af\3\2\2\2\u00b3\u00b4\3\2\2\2\u00b4\u00b2"+
		"\3\2\2\2\u00b4\u00b5\3\2\2\2\u00b5\u00b6\3\2\2\2\u00b6\u00b7\7\6\2\2\u00b7"+
		"\u00b8\b\13\1\2\u00b8\25\3\2\2\2\u00b9\u00ba\7\4\2\2\u00ba\u00bb\7\f\2"+
		"\2\u00bb\u00bc\5\4\3\2\u00bc\u00c0\b\f\1\2\u00bd\u00be\5\4\3\2\u00be\u00bf"+
		"\b\f\1\2\u00bf\u00c1\3\2\2\2\u00c0\u00bd\3\2\2\2\u00c1\u00c2\3\2\2\2\u00c2"+
		"\u00c0\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3\u00c4\3\2\2\2\u00c4\u00c5\7\6"+
		"\2\2\u00c5\u00c6\b\f\1\2\u00c6\27\3\2\2\2\u00c7\u00c8\7\4\2\2\u00c8\u00cc"+
		"\7\r\2\2\u00c9\u00ca\5\4\3\2\u00ca\u00cb\b\r\1\2\u00cb\u00cd\3\2\2\2\u00cc"+
		"\u00c9\3\2\2\2\u00cd\u00ce\3\2\2\2\u00ce\u00cc\3\2\2\2\u00ce\u00cf\3\2"+
		"\2\2\u00cf\u00d0\3\2\2\2\u00d0\u00d1\7\6\2\2\u00d1\u00d2\b\r\1\2\u00d2"+
		"\31\3\2\2\2\u00d3\u00d4\7\4\2\2\u00d4\u00d8\7\16\2\2\u00d5\u00d6\5\4\3"+
		"\2\u00d6\u00d7\b\16\1\2\u00d7\u00d9\3\2\2\2\u00d8\u00d5\3\2\2\2\u00d9"+
		"\u00da\3\2\2\2\u00da\u00d8\3\2\2\2\u00da\u00db\3\2\2\2\u00db\u00dc\3\2"+
		"\2\2\u00dc\u00dd\7\6\2\2\u00dd\u00de\b\16\1\2\u00de\33\3\2\2\2\u00df\u00e3"+
		"\7\4\2\2\u00e0\u00e4\7\17\2\2\u00e1\u00e2\7\20\2\2\u00e2\u00e4\b\17\1"+
		"\2\u00e3\u00e0\3\2\2\2\u00e3\u00e1\3\2\2\2\u00e4\u00e5\3\2\2\2\u00e5\u00e6"+
		"\7\6\2\2\u00e6\u00e7\b\17\1\2\u00e7\35\3\2\2\2\17EU`n|\u008a\u0098\u00a6"+
		"\u00b4\u00c2\u00ce\u00da\u00e3";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}